<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


return new class extends Migration
{

public function up(): void
{

Schema::create('ai_settings', function(Blueprint $table){

$table->id();

$table->string('provider')
->default('adaptive');


$table->string('model')
->nullable();


$table->text('api_key')
->nullable();


$table->string('status')
->default('active');


$table->timestamps();


});


}



public function down(): void
{

Schema::dropIfExists('ai_settings');

}

};