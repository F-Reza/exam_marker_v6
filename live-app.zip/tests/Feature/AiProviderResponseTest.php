<?php
namespace Tests\Feature;

use App\Contracts\DocumentReader;
use App\Exceptions\MarkingProviderException;
use App\Jobs\ProcessAssessment;
use App\Models\{Assessment, AiSetting, User};
use App\Services\AIPaperMarker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class AiProviderResponseTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutVite();
        $this->seed();
        config(['logging.default' => 'null', 'exam-marker.async' => false,
            'ai.provider' => 'gemini', 'ai.models.openai.key' => 'env-test-key']);
        AiSetting::query()->delete();
        AiSetting::create(['provider' => 'openai', 'model' => 'test-marking-model',
            'api_key' => 'saved-test-key', 'status' => 'active']);
        $this->app->instance(DocumentReader::class, new class implements DocumentReader {
            public function read(Assessment $assessment): array {
                return ['qp_text' => '1. What is force? [2]', 'ms_text' => 'A push or pull.',
                    'wa_text' => '1. A push or pull.', 'insert_text' => ''];
            }
        });
        Http::preventStrayRequests();
    }

    private function paper(): Assessment
    {
        $user = User::where('email', 'mode1@example.com')->firstOrFail();
        return Assessment::create(['user_id' => $user->id, 'title' => 'AI regression',
            'subject' => 'Physics', 'total_marks' => 2, 'status' => 'queued',
            'question_paper_path' => 'qp.pdf', 'written_answer_path' => 'wa.docx']);
    }

    private function validResult(): array
    {
        return ['questions' => [['question_number' => '1', 'max_marks' => 2,
            'ai_marks' => 2, 'confidence' => 'high', 'feedback' => 'Correct']],
            'percentage' => 100, 'grade' => 'A', 'summary' => []];
    }

    public function test_saved_admin_key_provider_and_model_are_used_to_complete_a_paper(): void
    {
        Http::fake(['api.openai.com/*' => Http::response(['choices' => [[
            'finish_reason' => 'stop', 'message' => ['content' => json_encode($this->validResult())]
        ]]])]);
        $paper = $this->paper();
        ProcessAssessment::dispatchSync($paper->id);
        $this->assertSame('review_required', $paper->fresh()->status);
        $this->assertSame(1, $paper->results()->count());
        Http::assertSent(fn ($r) => $r->hasHeader('Authorization', 'Bearer saved-test-key')
            && $r['model'] === 'test-marking-model' && str_contains($r->url(), 'api.openai.com'));
    }

    public function test_provider_errors_and_null_responses_fail_cleanly_without_saving_results(): void
    {
        foreach ([
            [401, ['error' => ['message' => 'secret-raw-body']], 'API key was rejected'],
            [403, ['error' => []], 'Access denied'],
            [404, ['error' => []], 'Model or API endpoint not found'],
            [429, ['error' => ['code' => 'insufficient_quota']], 'billing limit'],
            [429, ['error' => ['code' => 'rate_limit_exceeded']], 'Rate limit'],
            [400, ['error' => []], 'rejected the request'],
            [500, ['error' => []], 'provider request failed'],
            [200, ['choices' => [['message' => ['content' => null]]]], 'No readable'],
            [200, ['choices' => [['message' => ['content' => null, 'refusal' => 'declined']]]], 'declined'],
            [200, ['choices' => [['finish_reason' => 'length', 'message' => ['content' => '{}']]]], 'Incomplete'],
            [200, ['choices' => [['message' => ['content' => 'invalid-json']]]], 'Invalid JSON'],
            [200, ['choices' => [['message' => ['content' => 'null']]]], 'no question results'],
            [200, ['choices' => [['message' => ['content' => json_encode(['questions' => []])]]]], 'no question results'],
        ] as [$status, $body, $expected]) {
            Http::swap(new \Illuminate\Http\Client\Factory());
            Http::preventStrayRequests();
            Http::fake(['*' => Http::response($body, $status)]);
            $paper = $this->paper();
            try {
                ProcessAssessment::dispatchSync($paper->id);
                $this->fail('Expected provider failure');
            } catch (MarkingProviderException $e) {
                $this->assertStringContainsString($expected, $e->getMessage());
            }
            $this->assertSame('failed', $paper->fresh()->status);
            $this->assertStringContainsString($expected, $paper->fresh()->error_message);
            $this->assertStringNotContainsString('secret-raw-body', $paper->fresh()->error_message);
            $this->assertSame(0, $paper->results()->count());
        }
    }

    public function test_missing_key_fails_before_network_and_connection_error_is_safe(): void
    {
        $setting = AiSetting::first();
        $setting->update(['api_key' => null]);
        config(['ai.models.openai.key' => null]);
        Http::fake();
        try {
            app(AIPaperMarker::class)->mark($this->paper());
            $this->fail('Expected missing key');
        } catch (MarkingProviderException $e) {
            $this->assertStringContainsString('No API key', $e->getMessage());
        }
        Http::assertNothingSent();
        $setting->update(['api_key' => 'saved-test-key']);
        Http::fake(fn () => throw new ConnectionException('secret request url'));
        try {
            app(AIPaperMarker::class)->mark($this->paper());
            $this->fail('Expected connection failure');
        } catch (MarkingProviderException $e) {
            $this->assertStringContainsString('Connection failed', $e->getMessage());
            $this->assertStringNotContainsString('secret', $e->getMessage());
            $this->assertNull($e->getPrevious());
        }
    }

    public function test_impossible_marks_are_rejected(): void
    {
        $data = $this->validResult();
        $data['questions'][0]['ai_marks'] = 10;
        Http::fake(['*' => Http::response(['choices' => [['message' => ['content' => json_encode($data)]]]])]);
        $this->expectException(MarkingProviderException::class);
        $this->expectExceptionMessage('Invalid question marks');
        app(AIPaperMarker::class)->mark($this->paper());
    }
}
