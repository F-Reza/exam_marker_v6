<?php

namespace App\Services;


use App\Models\Assessment;
use App\Models\AiSetting;
use App\Exceptions\MarkingProviderException;
use Illuminate\Http\Client\Response;
use Illuminate\Http\Client\ConnectionException;
use App\Contracts\DocumentReader;
use Illuminate\Support\Facades\Http;


class AIPaperMarker implements PaperMarker
{


    public function __construct(
        private DocumentReader $reader,
        private WritingRubricService $writingRubric
    )
    {
    }





    public function mark(
        Assessment $assessment
    ): array
    {


        $docs = $this->reader->read($assessment);



        $prompt = $this->buildPrompt(
            $assessment,
            $docs
        );



        $response = $this->callAI(
            $prompt
        );



        return $this->parseResponse(
            $response
        );


    }







    private function buildPrompt(
        Assessment $assessment,
        array $docs
    ): string
    {


        $writingCriteria = json_encode(
            $this->writingRubric->criteria(),
            JSON_PRETTY_PRINT
        );



        return <<<PROMPT


You are an expert Cambridge IGCSE / IB examiner.



Subject:

{$assessment->subject}



Total Marks:

{$assessment->total_marks}



EXAMINER RULES:


1. Use ONLY the supplied mark scheme.

2. Do NOT divide marks equally.

3. Use exact marks from the mark scheme.

4. Mark every sub-question separately.

5. Provide examiner-quality feedback.

6. For writing questions use the supplied rubric.

7. Return ONLY valid JSON.



QUESTION PAPER:


{$docs['qp_text']}



MARK SCHEME:


{$docs['ms_text']}




WRITING RUBRIC:


{$writingCriteria}




STUDENT ANSWER:


{$docs['wa_text']}




RETURN JSON FORMAT:



{
"questions":[

{

"question_number":"1",

"question_part":"a",

"parent_question_number":"1",

"type":"normal",

"max_marks":2,

"ai_marks":1,

"confidence":"high",

"feedback":"Student identified the correct concept but explanation is incomplete.",

"criteria":[]

},


{

"question_number":"11",

"question_part":null,

"parent_question_number":"11",

"type":"writing",

"max_marks":25,

"ai_marks":20,


"writing_rubric":{


"content":{

"awarded":4,

"max_marks":5,

"feedback":"Ideas are relevant but need further development."

},


"organisation":{

"awarded":4,

"max_marks":5,

"feedback":"Clear paragraph structure and logical sequence."

},


"vocabulary":{

"awarded":4,

"max_marks":5,

"feedback":"Good vocabulary range with minor limitations."

},


"grammar":{

"awarded":3,

"max_marks":5,

"feedback":"Some grammatical errors affect accuracy."

},


"spelling":{

"awarded":5,

"max_marks":5,

"feedback":"Spelling and punctuation are accurate."

}


}


}

],



"percentage":80,


"grade":"7",



"summary":{

"strengths":[

""

],


"weaknesses":[

""

]

}


}



PROMPT;


    }









    private function callAI(
        string $prompt
    ): string
    {


        $setting = AiSetting::first();
        $provider = $setting && $setting->status === 'active'
            ? $setting->provider : config('ai.provider', 'openai');
        $config = config("ai.models.$provider", []);
        if (!is_array($config)) $config = [];
        if ($setting && $setting->status === 'active') {
            // The same settings that choose the engine must configure the request.
            if (filled($setting->api_key)) $config['key'] = $setting->api_key;
            if (filled($setting->model) && $setting->model !== 'adaptive-local-v1') {
                $config['model'] = $setting->model;
            }
        }
        foreach (['url', 'model'] as $field) {
            if (!isset($config[$field]) || !is_string($config[$field]) || trim($config[$field]) === '') {
                throw new MarkingProviderException('AI provider: Missing '.$provider.' '.$field.'. Update AI settings / server configuration.');
            }
        }
        if ($provider !== 'ollama' && empty($config['key'])) {
            throw new MarkingProviderException('AI provider: No API key configured for '.$provider.'. Add it in AI Settings or server configuration.');
        }

        try {
        switch($provider)
        {


            case 'openai':

                return $this->openAI(
                    $config,
                    $prompt
                );



            case 'gemini':

                return $this->gemini(
                    $config,
                    $prompt
                );



            case 'claude':

                return $this->claude(
                    $config,
                    $prompt
                );



            case 'azure':
            case 'openrouter':

                return $this->openAI(
                    $config,
                    $prompt
                );



            case 'ollama':

                return $this->ollama(
                    $config,
                    $prompt
                );



            default:

                throw new \Exception(
                    "AI provider not supported"
                );


        }
        } catch (ConnectionException $e) {
            // Do not retain a request exception: it can contain keys or paper text.
            throw new MarkingProviderException('AI provider: Connection failed or timed out. Check server internet access and provider availability, then retry.');
        }
    }

    private function openAI(
        array $config,
        string $prompt
    ): string
    {


        $client = Http::acceptJson()->connectTimeout(15)->timeout(120);
        $provider = AiSetting::first()?->provider ?? config('ai.provider');
        $client = $provider === 'azure'
            ? $client->withHeaders(['api-key' => $config['key']])
            : $client->withToken($config['key']);
        $r = $client->post($config['url'], [
            'model' => $config['model'],
            'messages' => [['role' => 'user', 'content' => $prompt]],
        ]);
        $this->checkHttpResponse($r);
        if ($r->json('choices.0.message.refusal')) {
            throw new MarkingProviderException('AI provider: The provider declined to mark this paper. Review the supplied content.');
        }
        if (in_array($r->json('choices.0.finish_reason'), ['length', 'content_filter', 'tool_calls'], true)) {
            throw new MarkingProviderException('AI provider: Incomplete marking response. Reduce the paper size or review the selected model and retry.');
        }
        return $this->responseText($r, 'choices.0.message.content');
    }

    private function checkHttpResponse(Response $r): void
    {
        if ($r->successful()) return;
        $code = $r->json('error.code');
        $reason = match ($r->status()) {
            401 => 'API key was rejected. Update the key in AI Settings.',
            403 => 'Access denied. Check project permissions and model access.',
            404 => 'Model or API endpoint not found. Check the selected model and endpoint.',
            429 => $code === 'insufficient_quota'
                ? 'API quota / billing limit reached. Check the API account billing and usage limits.'
                : 'Rate limit or quota reached. Check API usage / billing and retry later.',
            400, 422 => 'The provider rejected the request. Check the model, paper size and provider configuration.',
            default => 'The provider request failed. Check provider availability and retry.',
        };
        // Never include the raw provider body, which may echo secrets / input.
        throw new MarkingProviderException('AI provider: HTTP '.$r->status().'. '.$reason);
    }

    private function responseText(Response $r, string $path): string
    {
        $this->checkHttpResponse($r);
        $text = $r->json($path);
        if (!is_string($text) || trim($text) === '') {
            throw new MarkingProviderException('AI provider: No readable marking response returned. Check the selected model and retry.');
        }
        return $text;
    }

    private function gemini(
        array $config,
        string $prompt
    ): string
    {


        $url =
            $config['url']
            .'/'
            .$config['model']
            .':generateContent?key='
            .$config['key'];



        $r = Http::post(
            $url,
            [

                'contents'=>[

                    [

                        'parts'=>[

                            [
                                'text'=>$prompt
                            ]

                        ]

                    ]

                ]

            ]
        );



        return $this->responseText($r, 'candidates.0.content.parts.0.text');


    }









    private function claude(
        array $config,
        string $prompt
    ): string
    {


        $r = Http::withHeaders([

            'x-api-key'=>$config['key'],

            'anthropic-version'=>'2023-06-01'


        ])
        ->post(
            $config['url'],
            [

                'model'=>$config['model'],

                'max_tokens'=>4000,


                'messages'=>[

                    [

                        'role'=>'user',

                        'content'=>$prompt

                    ]

                ]


            ]
        );



        return $this->responseText($r, 'content.0.text');


    }









    private function ollama(
        array $config,
        string $prompt
    ): string
    {


        $r = Http::post(
            $config['url'],
            [

                'model'=>$config['model'],


                'messages'=>[

                    [

                        'role'=>'user',

                        'content'=>$prompt

                    ]

                ],


                'stream'=>false


            ]
        );



        return $this->responseText($r, 'message.content');


    }









    private function parseResponse(
        string $json
    ): array
    {


        $json = str_replace(
            [
                '```json',
                '```'
            ],
            '',
            $json
        );



        $json = trim($json);



        $data = json_decode(
            $json,
            true
        );



        if(json_last_error() !== JSON_ERROR_NONE)
        {

            throw new MarkingProviderException(
                'AI provider: Invalid JSON response: '
                .json_last_error_msg()
            );

        }



        if (!is_array($data) || empty($data['questions']) || !is_array($data['questions'])) {
            throw new MarkingProviderException('AI provider: Invalid marking response; no question results were returned. Retry this paper.');
        }
        foreach ($data['questions'] as $question) {
            if (!is_array($question) || !isset($question['question_number'], $question['max_marks']) || !isset($question['ai_marks']) ||
                !is_numeric($question['max_marks']) || !is_numeric($question['ai_marks']) ||
                $question['max_marks'] < 0 || $question['ai_marks'] < 0 || $question['ai_marks'] > $question['max_marks']) {
                throw new MarkingProviderException('AI provider: Invalid question marks returned. Retry this paper.');
            }
        }
        return $data;


    }



}