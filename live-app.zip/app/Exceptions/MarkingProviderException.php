<?php
namespace App\Exceptions;

// Messages in this exception are authored locally and contain no raw API body.
class MarkingProviderException extends \RuntimeException {}
