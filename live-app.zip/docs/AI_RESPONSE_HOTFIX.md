# Exam Marker V6 — AI response hotfix

The first screenshot identifies a null return from AIPaperMarker::openAI().
The second screenshot shows the earlier lifecycle patch reporting the failure.
That patch did not fix the AI request itself.

## Confirmed code defects fixed

- Active Admin AI settings now supply provider, model and saved encrypted API key to the marking request. Previously engine selection used the database but requests used a separate config source.
- Missing configuration fails before making a request.
- OpenAI-compatible requests check HTTP status before extracting content. Null/empty content, refusal and truncated output fail explicitly instead of causing a PHP string return TypeError.
- Locally authored messages explain rejected credentials, permissions, endpoint/model errors, quota/rate limits, connection failures and malformed results. Raw API response bodies and connection exception details are not included in these messages.
- Failed papers retain the retry flow. Provider failures cannot produce a successful paper or empty results.
- The existing PDF/DOC/DOCX and processing lifecycle fixes are included.

This fixes the confirmed request configuration and response handling defects.
It does not prove whether the live API response was caused by credentials,
billing, model access or another provider issue. A correctly configured API
account is still required. There is no live API test in this patch.

## Installation

Back up the existing application. Extract this ZIP into the Laravel project
root, preserving app/, config/, resources/, tests/ and docs/ paths.
No database migration and no .env replacement is included.

Run:

```bash
composer dump-autoload
php artisan optimize:clear
php artisan queue:restart
```

In Admin AI Settings, select your intended provider, enter a model supported
by that API account, and save the API key. The saved nonempty key/model take
precedence over config/ai.php. If none is saved, the configured environment
key and provider model are used. The old adaptive-local-v1 placeholder is
ignored for remote providers in favor of their configured model.

For local document reading keep EXAM_MARKER_OCR=local. Do not switch the
marker to demo/adaptive to hide a remote provider problem.

Open the existing failed assessment and click Start Paper Checking. A failed
assessment does not need a new upload. On success expect review_required and
question results. If it fails, send the new visible provider error (no API key
or personal answer content). For an unexpected generic error, inspect the
latest assessment-specific entry in storage/logs/laravel.log.

## Verification

Automated tests use fake HTTP responses and make no paid API requests.
Coverage includes saved key/model/provider precedence, valid marking result
persistence, HTTP 400/401/403/404/429/500, quota vs rate limit, null content,
refusal, truncated content, invalid JSON, empty results, impossible marks,
missing credentials and safe connection failure handling.

The screenshot's source booklet filename refers to system documentation;
confirm that the uploaded Insert actually belongs to the English paper.

Validation result: PHP 8.2.32, full application suite: 48 tests, 730 assertions passed. Provider requests were mocked; no live API credentials were used.
