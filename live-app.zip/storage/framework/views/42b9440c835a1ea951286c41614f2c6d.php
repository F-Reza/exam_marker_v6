<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/support-center.css')); ?>">
<?php $__env->stopPush(); ?>
<?php /**PATH /home/nextdigit/educatalyst.nextdigit.dev/resources/views/help/partials/styles.blade.php ENDPATH**/ ?>