@extends('layouts.app')
@section('title','My Papers')
@section('page-title','My Papers')
@section('content')
<div class="welcome">
    <div><h1>My papers</h1><p>Manage uploaded papers and open completed results.</p></div>
    <a class="btn" href="{{route('assessments.create')}}">＋ Check New Paper</a>
</div>
<section class="panel">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Assessment</th><th>Student</th><th>Uploaded</th><th>Status</th><th>Result</th><th></th></tr></thead>
            <tbody>
                @forelse($assessments as $a)
                <tr>
                    <td><b>{{$a->title}}</b><small>{{$a->subject}} · {{$a->total_marks}} marks</small></td>
                    <td>{{$a->student?->name ?? 'Individual'}}</td>
                    <td>{{$a->created_at->format('d M Y')}}</td>
                    <td><span class="status {{$a->status}}">{{str_replace('_',' ',$a->status)}}</span></td>
                    <td>
                        @if($a->results->isNotEmpty())
                            @if(auth()->user()->hasFeature('percentage') && $a->percentage !== null)
                                {{$a->percentage}}%
                            @else
                                {{$a->results->sum(fn($result) => $result->finalMarks())}} / {{$a->total_marks}}
                            @endif
                            @if(auth()->user()->hasFeature('grade') && $a->grade_awarded)
                                · {{$a->grade_awarded}}
                            @endif
                        @else
                            —
                        @endif
                    </td>
                    <td class="actions">
                        <a class="table-link" href="{{route($a->results->isNotEmpty() ? 'results.show' : 'assessments.show',$a)}}">Open</a>
                        @if(auth()->user()->canDeleteAssessment($a))
                        <form method="post" action="{{route('assessments.destroy',$a)}}" onsubmit="return confirm('Delete this assessment?')">
                            @csrf @method('DELETE')
                            <button class="danger-link">Delete</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="empty">No papers uploaded.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="pagination">{{$assessments->links()}}</div>
</section>
@endsection
